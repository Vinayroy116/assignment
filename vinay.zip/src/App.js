import React from 'react';
import { HashRouter, Route, Switch } from 'react-router-dom';
import HomePage from './components/Home';
import Profile from './components/profile';
import Contect from './components/Contect';
import Login from './components/Login';
import Career from './components/career';
function App() {
  return (
    <div className="App">
    <HashRouter>
      <Switch>
        <Route exact path="/" name='Login' component={Login}></Route>
        <Route exact path="/home" name='Home' component={HomePage}></Route>
        <Route exact path="/profile" name='Profile' component={Profile}></Route>
        <Route exact path="/content" name='Content' component={Contect}></Route>
        <Route exact path="/Career" name='Career' component={Career}></Route>


      </Switch>
    </HashRouter>
     
     
    </div>
  );
}

export default App;
