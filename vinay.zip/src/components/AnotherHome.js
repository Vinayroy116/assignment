import React from 'react'

export class AnotherHome extends React.Component {
    constructor(){
        super();
        this.state = {
            name : "naveen",
            lastName: "jakhar",
            count:0
        }
    }
    // panding for api
    // componentDidMount=()=>{
    //     this.setState({
    //         count:100
    //     });
    // }
    // componentWillUnmount=()=>{
    //     this.setState({
    //         count:80
    //     });
    // }
    // componentDidUpdate=()=>{

    // }
    render() {
        console.log("stste",this.state)
        return (
            <React.Fragment>
                <h1>Count {this.state.count === 5 ? "Naveen" : this.state.count }  </h1>
                <button type='submit'onClick={()=> this.setState({
                    count: this.state.count+1,
                    
                })} >Increase</button>
                <button type='submit' onClick={()=> this.setState({
                    count: this.state.count-1
                })} >DEcrease</button>
                <h1>This is another home page Class Base </h1>
                <ParentComponent state = {this.state}/>
            </React.Fragment>
            
        )
    }
}
const ParentComponent = (props)=>{
    console.log('props',props);
    return(
        <>
            <h1>This is Parenta Component and name is  {props.state.name}</h1>
            <ChildComponent 
                myprops = {props.ravali}
            />
        </>
    )
}
const ChildComponent = (props)=>{
    console.log('props in child',props);
    return(
        <>
            <h1>This is Child Component and props is  {props.myprops}</h1>
        </>
    )
}
export default AnotherHome
