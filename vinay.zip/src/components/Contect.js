import React from 'react'
import { Link } from 'react-router-dom'
const Contect = () => {
   
    
        var array = [
            {
                "albumId": 1,
                "id": 1,
                "title": "accusamus beatae ad facilis cum similique qui sunt",
                "url": "https://www.bigbasket.com/media/uploads/banner_images/hp_f_v_m_winterveggies_460-251221.jpg",
                "url1":"https://www.bigbasket.com/media/uploads/banner_images/hp_kgp_m_petstore_251221_400.jpg",
                "url2":"https://www.bigbasket.com/media/uploads/banner_images/hp_c_mousse_cxnp-6964_400_231221.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/92c952"
            },
            {
                "albumId": 1,
                "id": 2,
                "title": "reprehenderit est deserunt velit ipsam",
                "url": "https://www.bigbasket.com/media/uploads/banner_images/hp_h_k_m_newyearsale_460_251221.jpg",
                "url1":"https://www.bigbasket.com/media/uploads/banner_images/hp_kgp_m_babycare_251221_400.jpg",
                "url2":"https://www.bigbasket.com/media/uploads/banner_images/hp_c_pudding_cxnp-6966_400_231221.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/771796"
            },
            {
                "albumId": 1,
                "id": 3,
                "title": "officia porro iure quia iusto qui ipsa ut modi",
                "url": "https://www.bigbasket.com/media/uploads/banner_images/hp_b_h_m_wintercare_460_251221.jpg",
                "url1":"https://www.bigbasket.com/media/uploads/banner_images/hp_kgp_m_bcd_251221_400.jpg",
                "url2":"https://www.bigbasket.com/media/uploads/banner_images/hp_c_tart_cxnp-6965_400_231221.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/24f355"
            },
            {
                "albumId": 1,
                "id": 4,
                "title": "culpa odio esse rerum omnis laboriosam voluptate repudiandae",
                "url": "https://www.bigbasket.com/media/uploads/banner_images/hp_fom_m_bbpl-staples_460_281221_Bangalore.jpg",
                "url1":"https://www.bigbasket.com/media/uploads/banner_images/hp_kgp_m_health_suppliment_251221_400.jpg",
                "url2":"https://www.bigbasket.com/media/uploads/banner_images/hp_c_submit_cxnp-6968_400_231221.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/d32776"
            }
            
        ]
    
        let royArray = [
            {
                "albumId": 1,
                "id": 1,
                "title": "accusamus beatae ad facilis cum similique qui sunt",
                "url": "https://www.bigbasket.com/media/uploads/banner_images/hp-cmc-m-_EP_BIGS_1130x400-010122.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/92c952"
            }
        ]
    
        let ImageArray = [
            {
                "albumId": 1,
                "id": 1,
                "title": "Cabbage",
                "off": "GET 41% OFF",
                "opt": "1 Pc- Rs.6",
                "Price": ".Rs.6",
                "Delete": "Rs.8",
                "Timings": "Today 4:30pm-4:45pm",
                "url": "https://www.bigbasket.com/media/uploads/p/s/10000066_25-fresho-cabbage.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/92c952"
            },
            {
                "albumId": 1,
                "id": 2,
                "title": "Carrot",
                "opt": "250g- Rs 22.73",
                "opt1": "500g-Rs 45.45",
                "off": "GET 44% OFF",
                "Price": ".Rs.12",
                "Delete": "Rs.15",
                "Timings": "Today 5:30pm-7:30pm",
                "url": "https://www.bigbasket.com/media/uploads/p/s/10000072_16-fresho-carrot-orange.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/771796"
            },
            {
                "albumId": 1,
                "id": 3,
                "title": "Corainder Leaves",
                "off": "GET 20% OFF",
                "opt": "100g- Rs 7.00",
                "opt1": "250g-Rs 18",
                "Price": ".Rs.5",
                "Delete": "Rs.6.50",
                "Timings": "Today 6:30pm-7:00pm",
                "url": "https://www.bigbasket.com/media/uploads/p/s/10000097_19-fresho-coriander-leaves.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/24f355"
            },
            {
                "albumId": 1,
                "id": 4,
                "title": "Cucumber",
                "off": "GET 42% OFF",
                "opt": "500g- Rs 15.60",
                "opt1": "250g-Rs 7.50",
                "Price": ".Rs.15.60",
                "Delete": "Rs.9.50",
                "Timings": "Today 5:30pm-7:30pm",
                "url": "https://www.bigbasket.com/media/uploads/p/s/10000103_16-fresho-cucumber.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/92c952"
            }
    
        ]
    
    
        let BankArray = [
            {
                "albumId": 1,
                "id": 1,
                "title": "accusamus beatae ad facilis cum similique qui sunt",
                "url": "https://www.bigbasket.com/media/customPage/8dd4463a-4640-4d7c-a903-4989ed7ecd4e/1772988f-326d-471c-943d-62e6a7d77abb/3d9de59c-e394-4c18-a4cf-bbe876232fe6/hp_aff_m_citi_360_010122.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/92c952"
            },
            {
                "albumId": 1,
                "id": 2,
                "title": "reprehenderit est deserunt velit ipsam",
                "url": "https://www.bigbasket.com/media/customPage/8dd4463a-4640-4d7c-a903-4989ed7ecd4e/1772988f-326d-471c-943d-62e6a7d77abb/3d9de59c-e394-4c18-a4cf-bbe876232fe6/hp_aff_m_paytm_360_010122.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/771796"
            },
            {
                "albumId": 1,
                "id": 3,
                "title": "officia porro iure quia iusto qui ipsa ut modi",
                "url": "https://www.bigbasket.com/media/customPage/8dd4463a-4640-4d7c-a903-4989ed7ecd4e/1772988f-326d-471c-943d-62e6a7d77abb/3d9de59c-e394-4c18-a4cf-bbe876232fe6/hp_aff_m_rbl_360_010122.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/24f355"
            },
            {
                "albumId": 1,
                "id": 3,
                "title": "officia porro iure quia iusto qui ipsa ut modi",
                "url": "https://www.bigbasket.com/media/customPage/77880b23-0233-4fad-b54a-a93c998e0d20/2c1d9df8-99a9-4774-b776-c4711e9a36fd/bf9e86d3-4cdc-4034-b7d1-b23427c898c1/hp_aff_m_dbs-400_360_010122.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/24f355"
            }
        ]
    
        let ProductsArray = [
            {
                "albumId": 1,
                "id": 1,
                "title": "Toothpaste",
                "off": "SAVE Rs 5",
                "Price": ".Rs.97.85",
                "Delete": "Rs.103",
                "Timings": "Today 8:00AM-11:00AM",
                "opt": "1Pc- Rs.38",
                "opt1": "500ml-Rs 82",
                "opt2": "500ml Pack of 3 - Rs.238.47",
                "url": "https://www.bigbasket.com/media/uploads/p/s/263925_16-colgate-strong-teeth-anticavity-toothpaste-with-amino-shakti-formula-provides-fresher-breath.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/92c952"
            },
            {
                "albumId": 1,
                "id": 2,
                "title": "Tea",
                "off": "SAVE Rs 11",
                "Price": ".Rs.199.50",
                "Delete": "Rs.210",
                "Timings": "Today 8:00AM-11:00AM",
                "opt": "1Kg- Rs 710",
                "opt1": "500g-Rs 360",
                "opt2": "100g - Rs 80.47",
                "url": "https://www.bigbasket.com/media/uploads/p/s/266551_8-taj-mahal-tea.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/771796"
            },
            {
                "albumId": 1,
                "id": 3,
                "Price": ".Rs.38",
                "Delete": "Rs.40",
                "Timings": "Tommorow 8:00AM-1:00PM",
                "opt": "1Pc- Rs.38",
                "opt1": "500ml-Rs 82",
                "opt2": "500ml Pack of 3 - Rs.238.47",
                "off": "GET 5% OFF",
                "title": "Toilet Cleaner",
                "url": "https://www.bigbasket.com/media/uploads/p/s/263754_13-harpic-disinfectant-toilet-cleaner-liquid-original.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/24f355"
            },
            {
                "albumId": 1,
                "id": 4,
                "Price": ".Rs.318",
                "Delete": "Rs.330",
                "Timings": "Tommorow 12:00PM-3:00PM",
                "opt": "1L- Rs.314.84",
                "opt1": "550ml-Rs 194.60",
                "opt2": "250ml - Rs.110.35",
                "off": "SAVE Rs 17",
                "title": "Dettol",
                "url": "https://www.bigbasket.com/media/uploads/p/s/40124254_8-dettol-antiseptic-disinfectant-liquid.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/771796"
            }
        ]
        let TopArray = [
            {
                "albumId": 1,
                "id": 1,
                "title": "Strong Teeth Anticavity Toothpaste-With Amino Shakti Formula",
                "url": "https://www.bigbasket.com/media/customPage/77880b23-0233-4fad-b54a-a93c998e0d20/2c1d9df8-99a9-4774-b776-c4711e9a36fd/09b2e90a-29fc-46fd-b774-c598585ac69e/hp_topoffersStorefront_m_480_251221_01.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/92c952"
            },
            {
                "albumId": 1,
                "id": 2,
                "title": "Tea",
                "url": "https://www.bigbasket.com/media/customPage/77880b23-0233-4fad-b54a-a93c998e0d20/2c1d9df8-99a9-4774-b776-c4711e9a36fd/09b2e90a-29fc-46fd-b774-c598585ac69e/hp_topoffersStorefront_m_480_251221_02.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/771796"
            },
            {
                "albumId": 1,
                "id": 3,
                "title": "Disinfectant Toilet Cleaner Liquid",
                "url": "https://www.bigbasket.com/media/customPage/77880b23-0233-4fad-b54a-a93c998e0d20/2c1d9df8-99a9-4774-b776-c4711e9a36fd/09b2e90a-29fc-46fd-b774-c598585ac69e/hp_topoffersStorefront_m_480_251221_03.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/24f355"
            },
            {
                "albumId": 1,
                "id": 3,
                "title": "Disinfectant Toilet Cleaner Liquid",
                "url": "https://www.bigbasket.com/media/customPage/77880b23-0233-4fad-b54a-a93c998e0d20/2c1d9df8-99a9-4774-b776-c4711e9a36fd/09b2e90a-29fc-46fd-b774-c598585ac69e/hp_topoffersStorefront_m_480_251221_04.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/24f355"
            }
        ]
    
        let StoreArray = [
            {
                "albumId": 1,
                "id": 1,
                "title": "Strong Teeth Anticavity Toothpaste-With Amino Shakti Formula",
                "url": "https://www.bigbasket.com/media/customPage/77880b23-0233-4fad-b54a-a93c998e0d20/2c1d9df8-99a9-4774-b776-c4711e9a36fd/13905f34-8a1c-4e6a-8d2f-23172eb11868/hp_sbf_c_namkeens_chips_nachos_480_221221_01.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/92c952"
            },
            {
                "albumId": 1,
                "id": 2,
                "title": "Tea",
                "url": "https://www.bigbasket.com/media/customPage/77880b23-0233-4fad-b54a-a93c998e0d20/2c1d9df8-99a9-4774-b776-c4711e9a36fd/13905f34-8a1c-4e6a-8d2f-23172eb11868/hp_sbf_c_frozen_snacks_480_221221_02.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/771796"
            },
            {
                "albumId": 1,
                "id": 3,
                "title": "Disinfectant Toilet Cleaner Liquid",
                "url": "https://www.bigbasket.com/media/customPage/77880b23-0233-4fad-b54a-a93c998e0d20/2c1d9df8-99a9-4774-b776-c4711e9a36fd/13905f34-8a1c-4e6a-8d2f-23172eb11868/hp_sbf_c_soup_noodles_pasta_480_221221_03.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/24f355"
            },
            {
                "albumId": 1,
                "id": 3,
                "title": "Disinfectant Toilet Cleaner Liquid",
                "url": "https://www.bigbasket.com/media/customPage/77880b23-0233-4fad-b54a-a93c998e0d20/2c1d9df8-99a9-4774-b776-c4711e9a36fd/13905f34-8a1c-4e6a-8d2f-23172eb11868/hp_sbf_c_biscuits_cookies_480_221221_04.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/24f355"
            }
        ]
        let CleanArray = [
            {
                "albumId": 1,
                "id": 1,
                "title": "Toothpaste",
    
                "url": "https://www.bigbasket.com/media/customPage/77880b23-0233-4fad-b54a-a93c998e0d20/2c1d9df8-99a9-4774-b776-c4711e9a36fd/1e3acd61-1436-4c7e-99f1-9cfa7228fa7d/hp_home_cleaning_range_cleaningStorefront_m_480_221221_01.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/92c952"
            },
            {
                "albumId": 1,
                "id": 2,
                "title": "Tea",
                "url": "https://www.bigbasket.com/media/customPage/77880b23-0233-4fad-b54a-a93c998e0d20/2c1d9df8-99a9-4774-b776-c4711e9a36fd/1e3acd61-1436-4c7e-99f1-9cfa7228fa7d/hp_detergents_&_fabric_wash_cleaningStorefront_m_480_221221_02.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/771796"
            },
            {
                "albumId": 1,
                "id": 3,
                "title": " Toilet Cleaner",
                "url": "https://www.bigbasket.com/media/customPage/77880b23-0233-4fad-b54a-a93c998e0d20/2c1d9df8-99a9-4774-b776-c4711e9a36fd/1e3acd61-1436-4c7e-99f1-9cfa7228fa7d/hp_freshners_&_repellents_cleaningStorefront_m_480_221221_03.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/24f355"
            },
            {
                "albumId": 1,
                "id": 3,
                "title": " Toilet Cleaner",
                "url": "https://www.bigbasket.com/media/customPage/77880b23-0233-4fad-b54a-a93c998e0d20/2c1d9df8-99a9-4774-b776-c4711e9a36fd/1e3acd61-1436-4c7e-99f1-9cfa7228fa7d/hp_festive_pooja_needs_cleaningStorefront_m_480_221221_04.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/24f355"
            }
        ]
        let CerealsArray = [
            {
                "albumId": 1,
                "id": 1,
                "title": "Toothpaste",
    
                "url": "https://www.bigbasket.com/media/customPage/77880b23-0233-4fad-b54a-a93c998e0d20/2c1d9df8-99a9-4774-b776-c4711e9a36fd/a886f810-caec-4ee8-8a5c-87e9133d3dbd/hp_Att_&_flour_staplesStorefront_m_480_221221_01.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/92c952"
            },
            {
                "albumId": 1,
                "id": 2,
                "title": "Tea",
                "url": "https://www.bigbasket.com/media/customPage/77880b23-0233-4fad-b54a-a93c998e0d20/2c1d9df8-99a9-4774-b776-c4711e9a36fd/a886f810-caec-4ee8-8a5c-87e9133d3dbd/hp_Rice_&_Rice_products_staplesStorefront_m_480_221221_02.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/771796"
            },
            {
                "albumId": 1,
                "id": 3,
                "title": " Toilet Cleaner",
                "url": "https://www.bigbasket.com/media/customPage/77880b23-0233-4fad-b54a-a93c998e0d20/2c1d9df8-99a9-4774-b776-c4711e9a36fd/a886f810-caec-4ee8-8a5c-87e9133d3dbd/hp_Dal_&_Pulses_staplesStorefront_m_480_221221_03.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/24f355"
            },
            {
                "albumId": 1,
                "id": 3,
                "title": " Toilet Cleaner",
                "url": "https://www.bigbasket.com/media/customPage/77880b23-0233-4fad-b54a-a93c998e0d20/2c1d9df8-99a9-4774-b776-c4711e9a36fd/a886f810-caec-4ee8-8a5c-87e9133d3dbd/hp_Cooking_oils_&_Ghee_staplesStorefront_m_480_221221_04.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/24f355"
            }
        ]
        let HokitArray = [
            {
                "albumId": 1,
                "id": 1,
                "title": "Toothpaste",
                "url": "https://www.bigbasket.com/media/customPage/77880b23-0233-4fad-b54a-a93c998e0d20/2c1d9df8-99a9-4774-b776-c4711e9a36fd/5fde1813-e9e4-485d-b01d-c4f1ae597327/hp_kgp_c_Min_20_off_221221_01.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/92c952"
            },
            {
                "albumId": 1,
                "id": 2,
                "title": "Tea",
                "url": "https://www.bigbasket.com/media/customPage/77880b23-0233-4fad-b54a-a93c998e0d20/2c1d9df8-99a9-4774-b776-c4711e9a36fd/5fde1813-e9e4-485d-b01d-c4f1ae597327/hp_kgp_c_Min_50_off_221221_02.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/771796"
            },
            {
                "albumId": 1,
                "id": 3,
                "title": " Toilet Cleaner",
                "url": "https://www.bigbasket.com/media/customPage/77880b23-0233-4fad-b54a-a93c998e0d20/2c1d9df8-99a9-4774-b776-c4711e9a36fd/5fde1813-e9e4-485d-b01d-c4f1ae597327/hp_kgp_c_Bathroom_cleaning_needs_221221_06.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/24f355"
            },
            {
                "albumId": 1,
                "id": 3,
                "title": " Toilet Cleaner",
                "url": "https://www.bigbasket.com/media/customPage/77880b23-0233-4fad-b54a-a93c998e0d20/2c1d9df8-99a9-4774-b776-c4711e9a36fd/5fde1813-e9e4-485d-b01d-c4f1ae597327/hp_kgp_c_Cooking_needs_221221_04.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/24f355"
            }
        ]
    
        let lotarray = [
            {
                "albumId": 1,
                "id": 1,
                "title": "accusamus beatae ad facilis cum similique qui sunt",
                "url": "https://www.bigbasket.com/media/customPage/77880b23-0233-4fad-b54a-a93c998e0d20/2c1d9df8-99a9-4774-b776-c4711e9a36fd/96411c46-13c1-446e-8ba2-32df8722308e/hp_cmc_Amul_brandsStorefront_m_221221_01.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/92c952"
            },
            {
                "albumId": 1,
                "id": 2,
                "title": "reprehenderit est deserunt velit ipsam",
                "url": "https://www.bigbasket.com/media/customPage/77880b23-0233-4fad-b54a-a93c998e0d20/2c1d9df8-99a9-4774-b776-c4711e9a36fd/96411c46-13c1-446e-8ba2-32df8722308e/hp_cmc_Dettol_brandsStorefront_m_221221_02.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/771796"
            },
            {
                "albumId": 1,
                "id": 3,
                "title": "officia porro iure quia iusto qui ipsa ut modi",
                "url": "https://www.bigbasket.com/media/customPage/77880b23-0233-4fad-b54a-a93c998e0d20/2c1d9df8-99a9-4774-b776-c4711e9a36fd/96411c46-13c1-446e-8ba2-32df8722308e/hp_cmc_coca_cola_brandsStorefront_m_221221_03.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/24f355"
            },
            {
                "albumId": 1,
                "id": 4,
                "title": "culpa odio esse rerum omnis laboriosam voluptate repudiandae",
                "url": "https://www.bigbasket.com/media/customPage/77880b23-0233-4fad-b54a-a93c998e0d20/2c1d9df8-99a9-4774-b776-c4711e9a36fd/96411c46-13c1-446e-8ba2-32df8722308e/hp_cmc_Loreal_brandsStorefront_m_221221_04.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/d32776"
            },
            {
                "albumId": 1,
                "id": 5,
                "title": "natus nisi omnis corporis facere molestiae rerum in",
                "url": "https://www.bigbasket.com/media/customPage/77880b23-0233-4fad-b54a-a93c998e0d20/2c1d9df8-99a9-4774-b776-c4711e9a36fd/96411c46-13c1-446e-8ba2-32df8722308e/hp_cmc_India_gate_brandsStorefront_m_221221_05.jpg",
                "thumbnailUrl": "https://via.placeholder.com/150/f66b97"
            }
           
        ]
        return (
    
            <>
                <div class="col-md-12 pad-right mt-0 ">
                    <div class="text-right">
                        <ul class="list-unstyled list-inline right-section">
                            <li>
                                <span> <i class="bi bi-telephone-fill"></i>
                                    1860 123 1000</span>
                                <span>
                                    <div class="btn-group">
                                        <button type="button" class="btn  dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="bi bi-geo-alt"></i>   560031,Bangalore
                                        </button>
                                        <div class="dropdown-menu">
                                            <form class="row col-6">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">Email address</label>
                                                    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                                                    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                                                </div>
                                                <div class="form-group">
                                                    <label for="exampleInputPassword1">Password</label>
                                                    <input type="password" class="form-control" id="exampleInputPassword1" />
                                                </div>
                                                <div class="form-group form-check">
                                                    <input type="checkbox" class="form-check-input" id="exampleCheck1" />
                                                    <label class="form-check-label" for="exampleCheck1">Check me out</label>
                                                </div>
                                                <button type="submit" class="btn btn-primary">Continue</button>
                                            </form>
    
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item" href="#">Separated link</a>
                                        </div>
                                    </div>
                                </span>
    
                            </li>
    
                        </ul>
    
                    </div>
    
                </div>
    
                <nav class="navbar navbar-light bg-light container-fluid mt-0 ">
                    <a class="navbar-brand col-6" href="#">
                        <img src="asset\image\download.png" width="100" height="100" class="d-inline-block align-top" alt="" loading="lazy" my="" />
    
                    </a>
    
                    <form class="form-inline">
    
    
                        <input class="form-control lg-2" type="search" placeholder="Search" aria-label="Search" />
                        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                    </form>
                </nav>
    
                <nav class="navbar navbar-expand-lg navbar-dark bg-success container-fluid">
    
                    <div class="collapse navbar-collapse" id="navbarNavDropdown">
                        <ul class="navbar-nav">
                            <li class="nav-item dropdown full-wid hvr-drop ">
                                <p class="nav-link dropdown-toggle my-0" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    SHOP BY CATEGORY
                                </p>
                                <div class="dropdown-menu " aria-labelledby="navbarDropdownMenuLink">
                                    <p class="dropdown-item my-0" >Fruits & Vegetables</p>
                                    <p class="dropdown-item my-0" >Food grains,oil & masala</p>
                                    <p class="dropdown-item my-0" >Bakery, cakes & Diary</p>
                                    <p class="dropdown-item my-0" >Beverages</p>
                                    <p class="dropdown-item my-0" >Beauty & hygiene</p>
                                    <p class="dropdown-item my-0" >Cleaning & Household</p>
                                    <p class="dropdown-item my-0" >Kitchen,Garden & Pets</p>
                                    <p class="dropdown-item my-0" >Eggs,Meat & Fish</p>
                                    <p class="dropdown-item my-0" >Baby Care</p>
                                </div>
    
                            </li>
                            <li class="nav-item active">
                                <p class="nav-link" >OFFERS<span class="sr-only"></span></p>
                            </li>
                            <li class="nav-item">
                                <p class="nav-link" href="#">BB EXPRESS</p>
                            </li>
                            <li class="nav-item">
                                <p class="nav-link">BB SPECIALTY</p>
                            </li>
                        </ul>
                    </div>
                </nav>
    
                <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                        {
                            array.map((myImage, index) => {
                                return (
                                    <div className={`carousel-item ${index === 1 && 'active'}`}>
                                        <img src={myImage.url} className="d-block w-100" alt="..." />
                                    </div>
    
    
                                )
                            })}
                    </div>
                    <center className="container">
                        <button type="button" class="btn btn-outline-secondary">Fresho  </button>
                        <button type="button" class="btn btn-outline-secondary">Offer on</button>
                        <button type="button" class="btn btn-outline-secondary">Winter </button>
                        <button type="button" class="btn btn-outline-secondary">Household</button>
                        <button type="button" class="btn btn-outline-secondary">Olive</button>
                        <button type="button" class="btn btn-outline-secondary">Home</button>
    
                    </center>
    
    
    
                    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
    
                </div>
                <center>
                    <div className='images container mt-5 my-5'>
                        <img className=" mr-3" src="asset\image\hp_button_m_03_60_251221.png" alt="" />
                        <img className=" mr-3" src="https://www.bigbasket.com/media/uploads/banner_images/hp_button_m_04_60_251221.png" alt="" />
                        <img className=" mr-3" src="https://www.bigbasket.com/media/uploads/banner_images/hp_button_m_01_60_251221.png" alt="" />
    
                        <img className=" mr-3" src="https://www.bigbasket.com/media/uploads/banner_images/hp_button_m_05_60_251221.png" alt="" />
                        <img className=" mr-3" src="https://www.bigbasket.com/media/uploads/banner_images/hp_button_m_09_60_251221.png" alt="" />
                    </div>
                </center>
    
    
                <center>
                    <div class="section-title  text-center my-3">
                        <div class="shadow-sm mb-5 bg-white rounded"><h1>My Smart Basket</h1></div>
                    </div>
                    <div class="row container justify-content-center align-items-center">
    
                        {
                            ImageArray.map((myObject, index) => {
                                return (
                                    <div className='col-sm-3 col-8 col-lg-4 col-xl-3 align-items-center py-4'>
                                        <div class="shadow-sm mb-5 bg-white rounded">
                                            <div class="card" >
                                                <div class="card-header text-right text-danger">{myObject.off} <i class="bi bi-asterisk"></i></div>
                                                <img src={myObject.url} class="card-img-top image-center" alt="..." />
                                                <div class="card-body">
                                                    <h5 class="card-title">{myObject.title}</h5>
                                                    <select class="form-control form-control-sm">
                                                        <option>{myObject.opt}</option>
                                                        <option>{myObject.opt1}</option>
                                                    </select>
                                                    <p class="card-text text-muted"><h12>MRP <del>{myObject.Delete}</del>{myObject.Price}</h12></p>
                                                    <p><i class="bi bi-bicycle"> <h15>Express Delivery:{myObject.Timings}</h15></i></p>
    
    
                                                    <div class="col-sm-5 col-xs-5 pad-0 align-item-center">
                                                        <button qa="add" type="button" class="btn btn-add bg-dark text-white col-xs-9" ng-click="vm.addToBasket(vm.selectedProduct);">Add <span class="bskt-icon"></span></button>
                                                    </div>
    
    
    
    
    
    
    
    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                )
                            })
                        }
                       
                    </div>
                </center>
    
                <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                        {
                            royArray.map((myPt, index) => {
                                return (
                                    <div className={`carousel-item ${index === 0 && 'active'}`}>
                                        <img src={myPt.url} className="d-block w-100" alt="..." />
                                    </div>
    
    
                                )
                            })}
                    </div>
    
                    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
    
                </div>
    
    
    
    
                <center>
                    <div class="section-title  text-center my-3 ">
                        <div class="shadow-sm mb-5 bg-white rounded"><h2>Bank Offers</h2></div>
                    </div>
                    <div class="row container justify-content-center align-items-center">
    
                        {
                            BankArray.map((myPay, index) => {
                                return (
                                    <div className='col-sm-3 align-items-center'>
                                        <div class="shadow-sm mb-5 bg-white rounded">
                                            <div class="card" >
                                                <img src={myPay.url} class="card-img-top image-center" alt="..." />
    
                                            </div>
                                        </div>
                                    </div>
                                )
                            })
                        }
    
                    </div>
                </center>
    
                <center>
                    <div class="section-title  text-center mt-5">
                        <div class="shadow-sm mb-5 bg-white rounded"><h1>Best Sellers</h1></div>
                    </div>
                    <div class="row container justify-content-center align-items-center">
    
                        {
                            ProductsArray.map((mydata, index) => {
                                return (
                                    <div className='col-sm-3 align-items-center '>
                                        <div class="shadow-sm mb-5 bg-white rounded">
                                            <div class="card" >
                                                <div class="card-header text-right text-danger">{mydata.off} <i class="bi bi-asterisk"></i></div>
                                                <img src={mydata.url} class="card-img-top image-center" alt="..." />
                                                <div class="card-body">
                                                    <h5 class="card-title">{mydata.title}</h5>
                                                    <select class="form-control form-control-sm">
                                                        <option>{mydata.opt}</option>
                                                        <option>{mydata.opt1}</option>
                                                        <option>{mydata.opt2}</option>
                                                    </select>
                                                    <p class="card-text text-muted"><h6>MRP <del>{mydata.Delete}</del>  </h6><h5>{mydata.Price}</h5></p>
                                                    <p><i class="bi bi-bicycle"> <h15>Standard Delivery: {mydata.Timings}</h15></i></p>
    
    
                                                    <div class="col-sm-5 col-xs-5 pad-0">
                                                        <button qa="add" type="button" class="btn btn-add bg-dark text-white col-xs-9" ng-click="vm.addToBasket(vm.selectedProduct);">Add <span class="bskt-icon"></span></button>
                                                    </div>
    
    
    
    
    
    
    
    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                )
                            })
                        }
    
                    </div>
    
    
                </center>
    
    
    
                <center>
                    <div class="section-title  text-center mt-5 ">
                        <div class="shadow-sm mb-5 bg-white rounded"><h2>Top Offers</h2></div>
                    </div>
                    <div class="row container justify-content-center align-items-center">
    
                        {
                            TopArray.map((myoffers, index) => {
                                return (
                                    <div className='col-sm-3 align-items-center  '>
                                        <div class="shadow-sm mb-5 bg-white rounded">
                                            <div class="card" >
                                                <img src={myoffers.url} class="card-img-top image-center" alt="..." />
    
                                            </div>
                                        </div>
                                    </div>
                                )
                            })
                        }
    
                    </div>
                </center>
    
                <center>
                    <div class="section-title  text-center mt-5 ">
                        <div class="shadow-sm mb-5 bg-white rounded"><h2>Your Daily Staples</h2></div>
                    </div>
                    <div class="row container justify-content-center align-items-center">
    
                        {
                            CerealsArray.map((myodd, index) => {
                                return (
                                    <div className='col-sm-3 align-items-center  '>
                                        <div class="shadow-sm mb-5 bg-white rounded">
                                            <div class="card" >
                                                <img src={myodd.url} class="card-img-top image-center" alt="..." />
    
                                            </div>
                                        </div>
                                    </div>
                                )
                            })
                        }
    
                    </div>
                </center>
    
    
                <center>
                    <div class="section-title  text-center mt-3 ">
                        <div class="shadow-sm mb-5 bg-white rounded"><h2>Snacks Store</h2></div>
                    </div>
                    <div class="row container justify-content-center align-items-center">
    
                        {
                            StoreArray.map((mysnack, index) => {
                                return (
                                    <div className='col-sm-3 align-items-center  '>
                                        <div class="shadow-sm mb-5 bg-white rounded">
                                            <div class="card" >
                                                <img src={mysnack.url} class="card-img-top image-center" alt="..." />
    
                                            </div>
                                        </div>
                                    </div>
                                )
                            })
                        }
    
                    </div>
                </center>
                <center>
                    <div class="section-title  text-center mt-3 ">
                        <div class="shadow-sm mb-5 bg-white rounded"><h2>Cleaning & Household</h2></div>
                    </div>
                    <div class="row container justify-content-center align-items-center">
    
                        {
                            CleanArray.map((myHouse, index) => {
                                return (
                                    <div className='col-sm-3 align-items-center  '>
                                        <div class="shadow-sm mb-5 bg-white rounded">
                                            <div class="card" >
                                                <img src={myHouse.url} class="card-img-top image-center" alt="..." />
    
                                            </div>
                                        </div>
                                    </div>
                                )
                            })
                        }
    
                    </div>
                </center>
    
                <center>
                    <div class="section-title  text-center mt-5 ">
                        <div class="shadow-sm mb-5 bg-white rounded"><h2>Home & Kitchen Essentials</h2></div>
                    </div>
                    <div class="row container justify-content-center align-items-center">
    
                        {
                            HokitArray.map((myeve, index) => {
                                return (
                                    <div className='col-sm-3 align-items-center  '>
                                        <div class="shadow-sm mb-5 bg-white rounded">
                                            <div class="card" >
                                                <img src={myeve.url} class="card-img-top image-center" alt="..." />
    
                                            </div>
                                        </div>
                                    </div>
                                )
                            })
                        }
    
                    </div>
                </center>
    
    
    
                <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                        {
                            array.map((mypet, index) => {
                                return (
                                    <div className={`carousel-item ${index === 0 && 'active'}`}>
                                        <img src={mypet.url1} className="d-block w-100" alt="..." />
                                    </div>
    
    
                                )
                            })}
                    </div>
    
                    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
    
                </div>
    
    
                <center>
                    <div class="section-title  text-center mt-5 ">
                        <div class="shadow-sm mb-5 bg-white rounded"><h2>Brand Store</h2></div>
                    </div>
                    <div class="row container justify-content-center align-items-center">
    
                        {
                            lotarray.map((myeve, index) => {
                                return (
                                    <div className='col align-items-center  '>
                                        <div class="shadow-sm mb-5 bg-white rounded">
                                            <div class="card" >
                                                <img src={myeve.url} class="card-img-top image-center" alt="..." />
    
                                            </div>
                                        </div>
                                    </div>
                                )
                            })
                        }
    
                    </div>
                </center>
    
    
    
    
                <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                    <div class="shadow-sm mb-5 bg-white rounded text-center"><h2>Featured Recipes</h2></div>
                        {
                            array.map((myset, index) => {
                                return (
                                    <div className={`carousel-item ${index === 0 && 'active'}`}>
                                        <img src={myset.url2} className="d-block w-100" alt="..." />
                                    </div>
    
    
                                )
                            })}
                    </div>
    
                    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
    
                </div>
    
                <div className=' Container Content mt-5'>
                    <span class="border border-dark">
                        <div className='Title'>
                            <h1>bigbasket – online grocery store</h1>
                            <p>Did you ever imagine that the freshest of fruits and vegetables, top quality pulses and food grains, dairy products and hundreds of branded items could be handpicked and delivered to your home,
                                all at the click of a button? India’s first comprehensive online megastore, bigbasket.com, brings a whopping 20000+ products with more than 1000 brands, to over 4 million happy customers.
                                From household cleaning products to beauty and makeup, bigbasket has everything you need for your daily needs. bigbasket.com is convenience personified We’ve taken away all the stress associated with
                                shopping for daily essentials, and you can now order all your household products and even buy groceries online without travelling long distances or standing in serpentine queues.
                                Add to this the convenience of finding all your requirements at one single source, along with great savings, and you will realize that bigbasket- India’s largest online supermarket, has revolutionized the
                                way India shops for groceries. Online grocery shopping has never been easier. Need things fresh? Whether it’s fruits and vegetables or dairy and meat, we have this covered as well! Get fresh eggs, meat, fish and more online at your convenience. Hassle-free Home Delivery options</p>
                            <p>We deliver to 25 cities across India and maintain excellent delivery times, ensuring that all your products from groceries to snacks branded foods reach you in time.</p>
                            <ul>
                                <li>Express Delivery: This super useful service can be availed by customers in cities like Bangalore, Mumbai, Pune, Chennai, Kolkata, Hyderabad and Delhi-NCR in which we deliver your orders to your doorstep in 90 Minutes.</li>
                                <li>BB Specialty stores: Missed out on buying that essential item from your favorite neighborhood store for tonight’s party? We’ll deliver it for you! From bakery, sweets and meat to flowers and chocolates, we deliver your order in 90 minutes, through a special arrangement with a nearby specialty store, verified by us.</li>
                                <li>Slotted Delivery: Pick the most convenient delivery slot to have your grocery delivered. From early morning delivery for early birds, to late-night delivery for people who work the late shift, bigbasket caters to every schedule.</li>
                            </ul>
                        </div>
                    </span>
                </div>
    
    
    
    
    
                
    
    
    
    
    
    
    
               
            </>
        
    )
}

export default Contect
