import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Profile from './profile';
import Contect from './Contect';
import Index from './Index';
import Career from './career';
const Home = (props) => {

    const [count, setCount] = useState(0);
    const [name, setName] = useState("navee");
    const [navs, setNavs] = useState("home");
    const ApiCall = () => {
        console.log("im called")
        fetch("https://panorbit.in/api/users.json").then(res => res.json()).then((result) => {
            console.log("result", result)

        },
            (error) => {
                console.log("error", error)
            })
    }
    return (
        <>
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                <a class="navbar-brand" href="#">Navbar</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavDropdown">
                    <ul class="navbar-nav">
                        <li class={`nav-item ${navs === "home" ? "active" : null}`} onClick={() => setNavs("home")}>
                            <a class="nav-link" >Home <span class="sr-only">(current)</span></a>
                        </li>
                        <li class={`nav-item ${navs === "profile" ? "active" : null}`} onClick={() => setNavs("profile")}>
                            <a class="nav-link" >Profile</a>
                        </li>
                       
                        <li class={`nav-item ${navs === "Contect" ? "active" : null}`} onClick={() => setNavs("Contect")} >
                            <a class="nav-link" >Content</a>
                        </li>
                        <li class={`nav-item ${navs === 'Career' ? 'active' : null}`} onClick={() => setNavs('Career')}>
                            <a class="nav-link">Career</a>
                        </li>
                        
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Dropdown link
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                <a class="dropdown-item" href="#">Action</a>
                                <a class="dropdown-item" href="#">Another action</a>
                                <a class="dropdown-item" href="#">Something else here</a>
                            </div>
                        </li>
                        
                    </ul>
                   
                </div>
            </nav>
            {
                navs === 'home' ?
                    <Index ApiCall={ApiCall} />
                    :
                    navs === 'profile' ?
                        <Profile />
                        :  navs === 'Contect'? <Contect/> 
                      :<Career/>
            }
        </>
    )
}



export default Home;

