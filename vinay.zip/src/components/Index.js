import React from 'react'

const Index = (props) => {
    return (
        <>
            <div className='container-fluid'>
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="https://c0.wallpaperflare.com/preview/944/356/969/concept-construction-page-site.jpg" class="d-block w-100" style={{height:600}} alt="..." />
    </div>
    <div class="carousel-item">
      <img src="https://media.istockphoto.com/photos/communication-network-concept-in-cyberspace-abstract-background-picture-id1283633813?b=1&k=20&m=1283633813&s=170667a&w=0&h=GmmR6AkrzW3cfJvr2mrpvVsgQe8AlUkagDbG9Klt7dQ=" class="d-block w-100" alt="..."  style={{height:600}}/>
    </div>
    <div class="carousel-item">
      <img src="https://y31uv4ra1.vo.llnwd.net/content/wp/tweaklibrary_com/uploads/2020/03/Best-Wallpaper-Websites-To-Download-HD-Backgrounds.jpg" class="d-block w-100" alt="..."  style={{height:600}}/>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>

  </a>
  
</div>

            </div>
            <button type='button' onClick={props.ApiCall()}>Api Call</button>
        </>
    )
}

export default Index

