import React from 'react';
import { Formik,Field } from 'formik';
import * as Yup from 'yup';

const SignupSchema = Yup.object().shape({
    email: Yup.string().email('Invalid email').required('Required Email id '),
    password: Yup.string().required('Password Is required'),

  });


const Login = (props) => {
   console.log(props)
    const initial = {
        email: '',
        password: ''
    }
    const loginPage =(values)=>{
        console.log(values,props.history)
        var ema = 'naveen@mail.com';
        var pass = "1234";
        if(values.email === ema && values.password === pass){
            props.history.push('/home')
        }

}
    return (
        <>
            <div className='container mt-5'>
                <div className='row'>
                    <div className='col loginDiv'>
                        <div className='row column'>
                            <div className='col-6 left-col'>
                                <div className='header text-center'>
                                    <img className='left-image' src='/assect/image/login.jpg' />
                                </div>
                            </div>
                            <div className='col-6 right-col'>
                                <div className='header text-center'>
                                    <h3 className='heading mt-3'>Login</h3>
                                </div>
                                <div className='text-start'>
                                    <Formik
                                        initialValues={initial}
                                        onSubmit={(values)=> loginPage(values)}
                                      validationSchema={SignupSchema}
                                    >
                                    {(props)=> <FormField {...props} />}
                                    </Formik>
                                   
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </>
    )
}
const FormField = (props) => {
    // console.log("props",props)
    return(
        <>
        
            <div class="form-group">
                <label for="exampleInputEmail1">Email address</label>
                <Field type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name='email' />
                {
                    props.errors && 
                    <small id="emailHelp" class="form-text text-muted errorolor" >{props.errors.email}</small>
                }
               
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Password</label>
                <Field type="password" class="form-control" id="exampleInputPassword1" name='password'/>
                {
                    props.errors && 
                    <small id="emailHelp" class="form-text text-muted errorolor" >{props.errors.password}</small>
                }
            </div>
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="exampleCheck1" />
                <label class="form-check-label" for="exampleCheck1">Check me out</label>
            </div>
            <button type="submit" class="btn btn-primary" onClick={props.handleSubmit} disabled={props.isSubmitting ? true : false}>Submit</button>
         
        </>
    )
}
export default Login
