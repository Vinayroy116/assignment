import React from 'react'

import { Link } from 'react-router-dom'
import { Formik, Field } from 'formik';
import * as Yup from 'yup';
const SignupSchema = Yup.object().shape({
    firstName: Yup.string().email('Invalid').required('Max 15 inputs'),
    lastName: Yup.string().required('Max 10 inputs'),
    MobileNo: Yup.number().required('Max 10'),
    email: Yup.string().email('Invalid email').required('Required Email id '),
    password: Yup.string().required('Password Is required'),

});
const Career = (props) => {

    console.log(props)
    const initial = {
        firstName: '',
        lastName: '',
        MobileNo: '',
        email: '',
        password: ''
    }
    const webPage = (values) => {
        console.log(values, props.history)
        var nam = 'Vinay ';
        var lana = 'Kumar'
        var ema = 'vinayc116@gmail.com';
        var pass = "12345";


    }
    return (
        <>
            <div className='container mt-5'>
                <div className='row'>
                    <div className='col CareerDiv'>
                        <div className='row column'>
                            <div className='col-6 left-col'>
                                <div className='header text-center'>
                                    <img className='left-image' />
                                </div>
                            </div>
                            <div className='col-6 right-col'>
                                <div className='header text-center'>
                                    <h3 className='heading mt-3'>Fill the Form</h3>
                                </div>
                                <div className='text-start'>
                                    <Formik
                                        initialValues={initial}
                                        onSubmit={(values) => webPage(values)}
                                        validationSchema={SignupSchema}
                                    >
                                        {(props) => <FormField {...props} />}
                                    </Formik>

                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>


        </>
    )
}
const FormField = (props) => {
    console.log("props", props)
    return (
        <>
            <div class="form-group mb-0">
                <label for="examplename">First Name</label>
                <Field type="firstName" class="form-control" id="examplefirstName" aria-describedby="  firstNameHelp" name=' firstName' />
                {
                    props.errors &&
                    <small id="nameHelp" class="form-text text-muted errorolor" >{props.errors.firstName}</small>
                }

            </div>
            <div class="form-group mb-0">
                <label for="exapleastName">Last name</label>
                <Field type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name='lastname' />
                {
                    props.errors &&
                    <small id="lastNameHelp" class="form-text text-muted errorolor" >{props.errors.lastName}</small>
                }

            </div>
            <div class="form-group">
                <label for="exampleInputEmail1">Email address</label>
                <Field type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name='email' />
                {
                    props.errors &&
                    <small id="emailHelp" class="form-text text-muted errorolor" >{props.errors.email}</small>
                }

            </div>
            <div class="form-group">
                <label for="exapleastName">Phone Number</label>
                <Field type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name='MobileNo' />
                {
                    props.errors &&
                    <small id="lastNameHelp" class="form-text text-muted errorolor" >{props.errors.MobileNo}</small>
                }

            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Password</label>
                <Field type="password" class="form-control" id="exampleInputPassword1" name='password' />
                {
                    props.errors &&
                    <small id="emailHelp" class="form-text text-muted errorolor" >{props.errors.password}</small>
                }
            </div>
           
           
            <button type="submit" class="btn btn-primary" onClick={props.handleSubmit} disabled={props.isSubmitting ? true : false}>Submit</button>
        </>
    )
}


export default Career
