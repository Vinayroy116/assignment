import React from 'react'
import { Link } from 'react-router-dom'

const Profile = () => {
    return (
        <>
            <div className='container-fluid' style={{ height: 400, marginTop: 20 }}>

                <div className='row'>
                    <div className='col-3'>
                        <img src="https://c0.wallpaperflare.com/preview/944/356/969/concept-construction-page-site.jpg" class="d-block w-100" style={{ height: 400 }} alt="..." />
                    </div>
                    <div className='col-9'>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis ante eget massa porttitor, nec sagittis purus pulvinar. Praesent velit tellus, tempus in scelerisque eu, mattis accumsan purus. Suspendisse quis orci eget magna dapibus porta ut vitae diam. Maecenas dictum risus eu finibus viverra. Pellentesque nec mauris in ante efficitur sodales vel at est. Curabitur in sagittis tortor. Aenean vestibulum, velit eu consequat auctor, libero lectus dignissim metus, non cursus tellus arcu eu libero. Morbi aliquam sem vel orci vehicula efficitur. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</p>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis ante eget massa porttitor, nec sagittis purus pulvinar. Praesent velit tellus, tempus in scelerisque eu, mattis accumsan purus. Suspendisse quis orci eget magna dapibus porta ut vitae diam. Maecenas dictum risus eu finibus viverra. Pellentesque nec mauris in ante efficitur sodales vel at est. Curabitur in sagittis tortor. Aenean vestibulum, velit eu consequat auctor, libero lectus dignissim metus, non cursus tellus arcu eu libero. Morbi aliquam sem vel orci vehicula efficitur. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</p>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis ante eget massa porttitor, nec sagittis purus pulvinar. Praesent velit tellus, tempus in scelerisque eu, mattis accumsan purus. Suspendisse quis orci eget magna dapibus porta ut vitae diam. Maecenas dictum risus eu finibus viverra. Pellentesque nec mauris in ante efficitur sodales vel at est. Curabitur in sagittis tortor. Aenean vestibulum, velit eu consequat auctor, libero lectus dignissim metus, non cursus tellus arcu eu libero. Morbi aliquam sem vel orci vehicula efficitur. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</p>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis ante eget massa porttitor, nec sagittis purus pulvinar. Praesent velit tellus, tempus in scelerisque eu, mattis accumsan purus. Suspendisse quis orci eget magna dapibus porta ut vitae diam. Maecenas dictum risus eu finibus viverra. Pellentesque nec mauris in ante efficitur sodales vel at est. Curabitur in sagittis tortor. Aenean vestibulum, velit eu consequat auctor, libero lectus dignissim metus, non cursus tellus arcu eu libero. Morbi aliquam sem vel orci vehicula efficitur. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</p>
                    
                    </div>
                </div>

            </div>
        </>
    )
}

export default Profile
